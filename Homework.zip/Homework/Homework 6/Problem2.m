%% AEE 362 HW 6 - Problem 2

clc; clear; close all;

%% Givens
gamma = 1.4;
M_inf = 2.5;
tc = 0.1;

m_sym = 0.5;
m_uns = 0.2;

%% Maximum valid angle of attack
theta_max_deg = rad2deg(thetaMax(M_inf, gamma));

theta1_sym_deg = rad2deg(atan((tc/2)/m_sym));
theta1_uns_deg = rad2deg(atan((tc/2)/m_uns));

alphaMax_sym = theta_max_deg - theta1_sym_deg;
alphaMax_uns = theta_max_deg - theta1_uns_deg;
alphaMax_flat = theta_max_deg;

fprintf('Symmetric diamond alpha_max = %.6f deg\n', alphaMax_sym);
fprintf('Unsymmetric diamond alpha_max = %.6f deg\n', alphaMax_uns);
fprintf('Flat plate alpha_max = %.6f deg\n', alphaMax_flat);

%% Angle grids
nPts = 400;
alpha_sym = linspace(0, 0.98*alphaMax_sym, nPts);
alpha_uns = linspace(0, 0.98*alphaMax_uns, nPts);
alpha_flat = linspace(0, 0.98*alphaMax_flat, nPts);

%% Preallocate
CL_sym = zeros(size(alpha_sym));
CD_sym = zeros(size(alpha_sym));

CL_uns = zeros(size(alpha_uns));
CD_uns = zeros(size(alpha_uns));

CL_flat = zeros(size(alpha_flat));
CD_flat = zeros(size(alpha_flat));

%% Symmetric diamond
for k = 1:length(alpha_sym)
    [CL_sym(k), CD_sym(k)] = diamondCoeffs(M_inf, alpha_sym(k), tc, m_sym, gamma);
end

%% Unsymmetric diamond
for k = 1:length(alpha_uns)
    [CL_uns(k), CD_uns(k)] = diamondCoeffs(M_inf, alpha_uns(k), tc, m_uns, gamma);
end

%% Flat plate from Problem 1
for k = 1:length(alpha_flat)
    [CL_flat(k), CD_flat(k)] = flatPlateCoeffs(M_inf, alpha_flat(k), gamma);
end

%% Plot CL vs alpha
figure('Color','w');
hold on; grid on;
plot(alpha_sym, CL_sym, 'LineWidth', 1.5, 'DisplayName', 'Symmetric diamond, m = 0.5');
plot(alpha_uns, CL_uns, 'LineWidth', 1.5, 'DisplayName', 'Unsymmetric diamond, m = 0.2');
plot(alpha_flat, CL_flat, 'LineWidth', 1.5, 'DisplayName', 'Flat plate');
xlabel('\alpha (deg)');
ylabel('C_L');
title('C_L vs \alpha at M_\infty = 2.5');
legend('Location','northwest');

%% Plot CD vs alpha
figure('Color','w');
hold on; grid on;
plot(alpha_sym, CD_sym, 'LineWidth', 1.5, 'DisplayName', 'Symmetric diamond, m = 0.5');
plot(alpha_uns, CD_uns, 'LineWidth', 1.5, 'DisplayName', 'Unsymmetric diamond, m = 0.2');
plot(alpha_flat, CD_flat, 'LineWidth', 1.5, 'DisplayName', 'Flat plate');
xlabel('\alpha (deg)');
ylabel('C_D');
title('C_D vs \alpha at M_\infty = 2.5');
legend('Location','northwest');

%% Functions

function [CL, CD] = diamondCoeffs(Minf, alpha_deg, tc, m, gamma)

    h = tc/2;
    alpha = deg2rad(alpha_deg);

    theta1 = atan(h/m);
    theta2 = atan(h/(1-m));

    % Turning angles
    deltaUF = theta1 - alpha;    % upper-front
    deltaLF = theta1 + alpha;    % lower-front
    deltaR  = theta1 + theta2;   % rear-face expansion

    %  Upper front face 
    if deltaUF > 1e-12
        [M_UF, pUF_pinf] = compressionTurn(Minf, 1.0, deltaUF, gamma);
    elseif deltaUF < -1e-12
        [M_UF, pUF_pinf] = expansionTurn(Minf, 1.0, abs(deltaUF), gamma);
    else
        M_UF = Minf;
        pUF_pinf = 1.0;
    end

    %  Upper rear face
    [~, pUR_pinf] = expansionTurn(M_UF, pUF_pinf, deltaR, gamma);

    % Lower front face 
    [M_LF, pLF_pinf] = compressionTurn(Minf, 1.0, deltaLF, gamma);

    % Lower rear face 
    [~, pLR_pinf] = expansionTurn(M_LF, pLF_pinf, deltaR, gamma);

    % Pressure coefficients
    CpUF = (2/(gamma*Minf^2))*(pUF_pinf - 1);
    CpUR = (2/(gamma*Minf^2))*(pUR_pinf - 1);
    CpLF = (2/(gamma*Minf^2))*(pLF_pinf - 1);
    CpLR = (2/(gamma*Minf^2))*(pLR_pinf - 1);

    % Panel projections
    dxUF = m;      dzUF =  h;
    dxUR = 1 - m;  dzUR = -h;
    dxLF = m;      dzLF = -h;
    dxLR = 1 - m;  dzLR =  h;

    % Normal and axial coefficients
    CN = (CpLF*dxLF + CpLR*dxLR) - (CpUF*dxUF + CpUR*dxUR);
    CA = (CpUF*dzUF + CpUR*dzUR) - (CpLF*dzLF + CpLR*dzLR);

    % Lift and drag
    CL = CN*cos(alpha) - CA*sin(alpha);
    CD = CN*sin(alpha) + CA*cos(alpha);
end

function [M2, p2_pinf] = compressionTurn(M1, p1_pinf, delta, gamma)
    beta = solveBetaWeak(M1, delta, gamma);
    Mn1 = M1*sin(beta);

    p2_p1 = 1 + (2*gamma/(gamma+1))*(Mn1^2 - 1);

    Mn2 = sqrt((1 + (gamma-1)/2*Mn1^2) / (gamma*Mn1^2 - (gamma-1)/2));
    M2 = Mn2 / sin(beta - delta);

    p2_pinf = p1_pinf * p2_p1;
end

function [M2, p2_pinf] = expansionTurn(M1, p1_pinf, delta, gamma)
    nu1 = prandtlMeyer(M1, gamma);
    nu2 = nu1 + delta;
    M2 = invPrandtlMeyer(nu2, gamma);

    p2_p1 = ((1 + (gamma-1)/2*M1^2) / (1 + (gamma-1)/2*M2^2))^(gamma/(gamma-1));
    p2_pinf = p1_pinf * p2_p1;
end

function [CL, CD] = flatPlateCoeffs(Minf, alpha_deg, gamma)
    alpha = deg2rad(alpha_deg);

    beta = solveBetaWeak(Minf, alpha, gamma);
    Mn1 = Minf*sin(beta);
    pL_pinf = 1 + (2*gamma/(gamma+1))*(Mn1^2 - 1);

    nu_inf = prandtlMeyer(Minf, gamma);
    nu_upper = nu_inf + alpha;
    M_upper = invPrandtlMeyer(nu_upper, gamma);

    pU_pinf = ((1 + (gamma-1)/2*Minf^2) / ...
              (1 + (gamma-1)/2*M_upper^2))^(gamma/(gamma-1));

    Cp_lower = (2/(gamma*Minf^2))*(pL_pinf - 1);
    Cp_upper = (2/(gamma*Minf^2))*(pU_pinf - 1);

    CN = Cp_lower - Cp_upper;
    CL = CN*cos(alpha);
    CD = CN*sin(alpha);
end

function beta = solveBetaWeak(M, theta, gamma)
    mu = asin(1/M);

    if abs(theta) < 1e-12
        beta = mu;
        return;
    end

    [theta_max_val, beta_peak] = thetaMaxWithBeta(M, gamma);

    if theta >= theta_max_val
        theta = 0.999999 * theta_max_val;
    end

    beta_left  = mu + 1e-8;
    beta_right = beta_peak - 1e-8;

    f = @(beta) thetaFromBeta(M, beta, gamma) - theta;

    Nscan = 10000;
    beta_vals = linspace(beta_left, beta_right, Nscan);
    f_vals = arrayfun(f, beta_vals);

    idx = find(f_vals(1:end-1).*f_vals(2:end) <= 0, 1, 'first');

    if ~isempty(idx)
        beta = fzero(f, [beta_vals(idx), beta_vals(idx+1)]);
        return;
    end

    [fmin_abs, j] = min(abs(f_vals));
    if fmin_abs < 1e-8
        beta = beta_vals(j);
        return;
    end

    error('Could not bracket weak-shock root.');
end

function theta_val = thetaFromBeta(M, beta, gamma)
    theta_val = atan(2*cot(beta) .* ...
        ((M^2 .* sin(beta).^2 - 1) ./ ...
        (M^2 .* (gamma + cos(2*beta)) + 2)));
end

function [theta_max_val, beta_peak] = thetaMaxWithBeta(M, gamma)
    beta_min = asin(1/M) + 1e-8;
    beta_max = pi/2 - 1e-8;

    fneg = @(beta) -thetaFromBeta(M, beta, gamma);
    beta_peak = fminbnd(fneg, beta_min, beta_max);

    theta_max_val = thetaFromBeta(M, beta_peak, gamma);
end

function theta_max_val = thetaMax(M, gamma)
    [theta_max_val, ~] = thetaMaxWithBeta(M, gamma);
end

function nu = prandtlMeyer(M, gamma)
    nu = sqrt((gamma+1)/(gamma-1)) * ...
         atan(sqrt(((gamma-1)/(gamma+1))*(M^2 - 1))) ...
       - atan(sqrt(M^2 - 1));
end

function M = invPrandtlMeyer(nu_target, gamma)
    f = @(M) prandtlMeyer(M, gamma) - nu_target;
    M = fzero(f, [1 + 1e-8, 50]);
end