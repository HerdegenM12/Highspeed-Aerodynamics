%% AEE 362 Homework 5 - Problem 1

clc; clear; close all;

%% Givens
gamma = 1.4;
Mi_design = 1.8;     % inlet Mach number
Ae_At = 1.6;     % exit-to-throat area ratio
Mi_part_c = 2.0;     % inlet Mach number for part (c)

%% Part A
Ai_At = areaMach(Mi_design, gamma);
Me = fzero(@(M) areaMach(M, gamma) - Ae_At, [1e-6, 0.999999]);

%% Part B
M2_intake = fzero(@(M) areaMach(M, gamma) - Ai_At, [1e-6, 0.999999]);
M1_shock = fzero(@(M1) shockDownstream(M1, gamma) - M2_intake, [1.0001, 10]);

%% Part C
Ai_Astar_partc = areaMach(Mi_part_c, gamma);
At_Astar_partc = Ai_Astar_partc / Ai_At;
Mt = fzero(@(M) areaMach(M, gamma) - At_Astar_partc, [1.0001, Mi_part_c]);

%% Display Results
fprintf('Ai/At = %.6f\n', Ai_At);
fprintf('Me = %.6f\n\n', Me);
fprintf('Post-shock intake Mach, M2 = %.6f\n', M2_intake);
fprintf('Flight Mach for shock at intake, M1 = %.6f\n\n', M1_shock);
fprintf('At/A* at Mi = 2.0 = %.6f\n', At_Astar_partc);
fprintf('Throat Mach number, Mt = %.6f\n', Mt);

%% Helper Functions
function AR = areaMach(M, gamma)
    % Isentropic area-Mach relation: A/A*
    AR = (1 ./ M) .* ...
        ((2 / (gamma + 1)) .* (1 + (gamma - 1)/2 .* M.^2)) ...
        .^ ((gamma + 1) / (2 * (gamma - 1)));
end

function M2 = shockDownstream(M1, gamma)
    % Downstream Mach number for a normal shock
    M2 = sqrt((1 + (gamma - 1)/2 .* M1.^2) ./ ...
              (gamma .* M1.^2 - (gamma - 1)/2));
end
