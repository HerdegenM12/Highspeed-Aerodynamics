%% AEE 362 – HW1 Part 2 - 1

clear; clc;

%% Parameters
% Chamber conditions
Tc  = 1500;  % K
pc  = 970e3;  % Pa

% Exit plane conditions
De  = 0.10;  % m, exit diameter
pe  = 70e3;  % Pa
Te  = 750;    % K
Ve  = 1300;   % m/s
pa  = 101e3;  % Pa,

% Gas properties
Ru  = 8314;          % J/(kmol*K)
M   = 28;            % kg/kmol
cp  = 1126;          % J/(kg*K)

%% Solution
% Area
Ae = pi*De^2/4;      % m^2, circular exit area

% Gas constant
R  = Ru/M;           % J/(kg*K)

% Mass flow rate
rho_e = pe/(R*Te);   % kg/m^3
mdot = rho_e * Ae * Ve;  % kg/s

% Thrust
F = mdot*Ve + (pe - pa)*Ae;   % N

% Energy Addition
he = cp*Te;           % J/kg
KEe = Ve^2/2;         % J/kg
Qdot_comb = mdot*(he + KEe);   % W

%% Reults
fprintf('Results for Part 2, Q1\n');
fprintf('Exit area Ae            = %.6f m^2\n', Ae);
fprintf('Exit density rho_e      = %.4f kg/m^3\n', rho_e);
fprintf('Mass flow rate mdot     = %.3f kg/s\n', mdot);
fprintf('Thrust F                = %.1f N (%.3f kN)\n', F, F/1000);
fprintf('Combustion power Qdot   = %.3e W (%.2f MW)\n', Qdot_comb, Qdot_comb/1e6);