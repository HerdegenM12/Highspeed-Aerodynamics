%% Reflected Shock Calculator

clear; clc; close all;

%% Parameters
% Region 2
p2_kPa = 173.467;   
T2 = 604.0;    
u2 = 544.581;  
% Gas properties for regions 2-3
gamma = 1.4;          
R = 287.0;         

% Unit conversion
p2 = p2_kPa * 1e3;

%% Derived properties in region 2
a2 = sqrt(gamma * R * T2); 
cp = gamma * R / (gamma - 1); 
rho2 = p2 / (R * T2);  

%% Solve for reflected shock speed magnitude V_R from
A = 2;
B = -(gamma - 3) * u2;
C = -(2*a2^2 + (gamma - 1)*u2^2);

disc = B^2 - 4*A*C;
rootsVR = (-B + [-1, 1]*sqrt(disc)) / (2*A);

% Choose the positive root
rootsVR = rootsVR(isreal(rootsVR) & rootsVR > 0);
V_R = max(rootsVR); 

%% Region 3 properties
p3  = p2 + rho2 * u2 * (u2 + V_R);                
T3  = T2 + (u2^2 + 2*u2*V_R) / (2*cp);     
rho3 = rho2 * (u2 + V_R) / V_R;   
a3 = sqrt(gamma * R * T3);

% Useful Mach numbers
M_R = (u2 + V_R) / a2;     % upstream Mach relative to reflected shock
M3  = V_R / a3;            % downstream Mach relative to reflected shock 

%% Print results neatly
fprintf('\nPart (b) computed values:\n');
fprintf(' V_R = %.3f m/s\n', V_R);
fprintf(' p3 = %.3f kPa\n', p3/1e3);
fprintf(' T3 = %.3f K\n', T3);
fprintf(' rho3 = %.6f kg/m^3\n', rho3);

fprintf(' a2 = %.3f m/s,  a3 = %.3f m/s\n', a2, a3);
fprintf('  M_R = %.4f (upstream rel. Mach),  M3 = %.4f (downstream rel. Mach)\n', M_R, M3);