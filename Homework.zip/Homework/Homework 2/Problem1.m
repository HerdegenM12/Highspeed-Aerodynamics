%% AEE HW 2 - Question 2

clc; clear; close all;

%% Parameters
% Exit plane conditions
De  = 0.10;  % m, exit diameter
pe  = 70e3;  % Pa
Tc  = 750;    % K
Ve  = 1300;   % m/s
pa  = 101e3;  % Pa,

% Gas properties
Ru  = 8314;          % J/(kmol*K)
M   = 28;            % kg/kmol
cp  = 1126;          % J/(kg*K)
R_univ = 8314;        % J/(kg-mol*K)

% Gas constants
R = Ru / M; 
cv = cp - R; 
gamma = cp / cv; 

% Upstream Mach number at nozzle exit
a1 = sqrt(gamma * R * Tc);  
M1 = Ve / a1;   

% Normal shock relations
p2_p1 = 1 + 2*gamma/(gamma+1) * (M1^2 - 1);  
rho2_rho1 = ( (gamma+1)*M1^2 ) / ( 2 + (gamma-1)*M1^2 );
T2_T1 = p2_p1 / rho2_rho1;  
M2_sq = (1 + 0.5*(gamma-1)*M1^2) / (gamma*M1^2 - 0.5*(gamma-1));
M2 = sqrt(M2_sq);

p2 = p2_p1 * pe;              % downstream pressure [Pa]
T2 = T2_T1 * Tc;              % downstream temperature [K]

a2 = sqrt(gamma * R * T2); 
V2 = M2 * a2; 

% Convert p2 back to kPa for reporting
p2_kPa = p2 / 1e3;

fprintf('gamma = %.3f\n', gamma);
fprintf('M1 = %.3f\n', M1);
fprintf('Downstream of normal shock\n');
fprintf('M2   = %.3f\n', M2);
fprintf('V2   = %.1f m/s\n', V2);
fprintf('T2   = %.1f K\n', T2);
fprintf('p2   = %.1f kPa\n', p2_kPa);