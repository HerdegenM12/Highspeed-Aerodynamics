clear; clc; close all;

% Hard coded M and Cl values
M = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9];
CL_actual = [0.817227 0.806553 0.821670 0.848208 0.888519 ...
             0.949731 0.682949 0.490775 0.512878 0.669387];

% Incompressible estimated
CL0 = CL_actual(1)*sqrt(1 - M(1)^2);

% Prandtl-Glauert prediction
CL_PG = CL0 ./ sqrt(1 - M.^2);

figure('Color','w');
plot(M, CL_actual, '-o', 'LineWidth', 1.5, 'DisplayName', 'HW1 numerical data');
hold on; grid on;
plot(M, CL_PG, '-s', 'LineWidth', 1.5, 'DisplayName', 'Prandtl-Glauert');
xlabel('Mach number');
ylabel('C_L');
title('NACA 4412 at \alpha = 4^\circ');
legend('Location','northwest');