clc; clear; close all;

%% Constants
gamma = 1.4;
M_data = 0.1;

%% Open and read file
fid = fopen('4412_Ma01Cp.txt','r');
fgetl(fid);
data = textscan(fid, '%f %f %f %f', 'Delimiter', '\t', ...
    'MultipleDelimsAsOne', true, 'CollectOutput', true);

fclose(fid);
data = data{1};
X  = data(:,1);
Y  = data(:,2);
Z  = data(:,3);
Cp = data(:,4);

%% Check imported values
Cp_min_data = min(Cp);

% Convert to incompressible reference
Cp0_min = Cp_min_data * sqrt(1 - M_data^2);

fprintf('Cp0_min = %.6f\n', Cp0_min);

%% Define functions
Cp_cr = @(M) (2 ./ (gamma .* M.^2)) .* ...
    ( ((1 + ((gamma-1)/2).*M.^2) ./ (1 + (gamma-1)/2)).^(gamma/(gamma-1)) - 1 );

Cp_min_corr = @(M) Cp0_min ./ sqrt(1 - M.^2);
Mvals = linspace(0.30, 0.90, 20000);

Cp_corr_vals = Cp_min_corr(Mvals);
Cp_cr_vals   = Cp_cr(Mvals);

diff_vals = abs(Cp_corr_vals - Cp_cr_vals);

[~, idx] = min(diff_vals);
Mcr = Mvals(idx);

fprintf('Estimated critical Mach number Mcr = %.6f\n', Mcr);
fprintf('At Mcr: corrected Cp_min = %.6f\n', Cp_corr_vals(idx));
fprintf('At Mcr: critical Cp_cr   = %.6f\n', Cp_cr_vals(idx));