%% AEE HW 2 - Question 3

clc; clear; close all;

%% Parameters
gamma = 1.4;
T1 = 310;  % K
M1 = 1.0;
T2 = 240;  % K
p_res = 100;  % kPa

%% Stagnation temperature from 1
T0 = T1 * (1 + 0.5*(gamma-1)*M1^2);

%% Mach upstream of shock
M2 = sqrt((T0/T2 - 1) / (0.5*(gamma-1)));

%% Normal shock relations
p3_p2 = 1 + 2*gamma/(gamma+1) * (M2^2 - 1); 
rho3_rho2 = ( (gamma+1)*M2^2 ) / ( 2 + (gamma-1)*M2^2 );
T3_T2 = p3_p2 / rho3_rho2;
M3 = sqrt((1 + 0.5*(gamma-1)*M2^2) / ...
          (gamma*M2^2 - 0.5*(gamma-1))); 

% Isentropic p0/p at states 2 and 3
p0_p2 = (1 + 0.5*(gamma-1)*M2^2)^(gamma/(gamma-1));
p0_p3 = (1 + 0.5*(gamma-1)*M3^2)^(gamma/(gamma-1));

% Pressure ratio across shock
p0_3_over_p0_2 = p3_p2 * p0_p3 / p0_p2;

% Solve p2 and p1
p0_3 = p_res;  % kPa
p0_2 = p0_3 / p0_3_over_p0_2;  % kPa
p2   = p0_2 / p0_p2; % kPa

% At location 1 (M1 = 1)
p0_p1 = (1 + 0.5*(gamma-1)*M1^2)^(gamma/(gamma-1));
p1   = p0_2 / p0_p1; % kPa

%% Print Results
fprintf('M2 = %.3f\n', M2);
fprintf('T_res = %.1f K\n', T0);
fprintf('p1 = %.2f kPa\n', p1);
fprintf('M3 = %.2f \n', M3);