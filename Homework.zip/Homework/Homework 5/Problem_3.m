%% AEE 362 HW 5 - Problem 3

clc; clear; close all;

%% Givens
gamma = 1.4;
Theta = 30;           
delta = Theta/2;  
delta1 = deg2rad(delta);
fprintf('Included wedge angle = %.2f deg\n', Theta);
fprintf('Flow deflection per side = %.2f deg\n\n', delta);

%% Find minimum Mach number for attached shock
f_attach = @(M) deltaMax(M, gamma) - delta;
M_min_attach = fzero(f_attach, [1.01 5]);
fprintf('Minimum Mach number for attached shock = %.6f\n\n', M_min_attach);

%% Check M = 1.2 and M = 1.3
M_check = [1.2, 1.3];
for k = 1:length(M_check)
    M = M_check(k);
    dmax = deltaMax(M, gamma);
    fprintf('For M = %.3f:\n', M);
    fprintf('   delta_max = %.6f deg\n', dmax);
    if delta <= dmax
        fprintf('   Attached shock is possible.\n');
        beta = solveBetaWeak(M, delta1, gamma);
        fprintf('   Weak shock angle beta = %.6f deg\n\n', rad2deg(beta));
    else
        fprintf('   Attached shock is NOT possible.\n');
        fprintf('   Shock will be detached.\n\n');
    end
end

%% Local functions
function res = thetaBetaResidual(beta, M, delta, gamma)
    % theta-beta-M equation residual
    res = tan(delta) - 2*cot(beta) .* ...
        ((M.^2 .* sin(beta).^2 - 1) ./ (M.^2 .* (gamma + cos(2*beta)) + 2));
end

function d_deg = deltaMax(M, gamma)
    % Returns maximum turning angle (degrees) for attached oblique shock
    beta_min = asin(1/M) + 1e-6;
    beta_max = pi/2 - 1e-6;

    fun = @(beta) -atan( 2*cot(beta) .* ...
        ((M.^2 .* sin(beta).^2 - 1) ./ (M.^2 .* (gamma + cos(2*beta)) + 2)) );

    beta_star = fminbnd(fun, beta_min, beta_max);
    d_rad = -fun(beta_star);
    d_deg = rad2deg(d_rad);
end

function beta = solveBetaWeak(M, delta, gamma)
    % Solves for weak-shock beta
    beta_min = asin(1/M) + 1e-6;
    beta_max = pi/2 - 1e-6;

    f = @(beta) tan(delta) - 2*cot(beta) .* ...
        ((M.^2 .* sin(beta).^2 - 1) ./ (M.^2 .* (gamma + cos(2*beta)) + 2));

    % Search for sign changes and pick first one = weak root
    N = 2000;
    beta_vals = linspace(beta_min, beta_max, N);
    f_vals = arrayfun(f, beta_vals);

    idx = find(f_vals(1:end-1).*f_vals(2:end) < 0, 1, 'first');

    if isempty(idx)
        error('No attached oblique shock solution exists for this M and delta.');
    end

    beta = fzero(f, [beta_vals(idx), beta_vals(idx+1)]);
end