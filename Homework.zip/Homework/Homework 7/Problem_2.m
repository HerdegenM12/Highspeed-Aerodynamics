clc; clear; close all;

%% Givens
M_list = [1.5, 2.5, 4.0];
alpha_deg = linspace(0,10,400); 
alpha_rad = deg2rad(alpha_deg);   % convert to radians

%% CL and CD
CL_all = zeros(length(M_list), length(alpha_deg));
CD_all = zeros(length(M_list), length(alpha_deg));

%% Compute CL and CD for each Mach number
for i = 1:length(M_list)
    M = M_list(i);

    beta = sqrt(M^2 - 1);

    % Linear small-disturbance theory for a flat plate
    CL_all(i,:) = 4 .* alpha_rad ./ beta;
    CD_all(i,:) = 4 .* alpha_rad.^2 ./ beta;
end

%% Plot CL vs alpha
figure('Color','w');
hold on; grid on;
for i = 1:length(M_list)
    plot(alpha_deg, CL_all(i,:), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('M = %.1f', M_list(i)));
end
xlabel('\alpha (deg)');
ylabel('C_L');
title('C_L vs \alpha');
legend('Location','northwest');

%% Plot CD vs alpha
figure('Color','w');
hold on; grid on;
for i = 1:length(M_list)
    plot(alpha_deg, CD_all(i,:), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('M = %.1f', M_list(i)));
end
xlabel('\alpha (deg)');
ylabel('C_D');
title('C_D vs \alpha');
legend('Location','northwest');