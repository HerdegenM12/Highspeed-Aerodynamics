%% AEE362 - HW 1 Part 1 

clear; clc; close all;

dataDir = fullfile(pwd, "data_files");
alpha_deg = 4;
alpha = deg2rad(alpha_deg);

% Aerodynamic center
x_ac = 0.25;
z_ac = 0.0;
machs = [0.1:0.1:0.9 0.85];
machs = sort(machs);
cl   = zeros(size(machs));
cd   = zeros(size(machs));
cmac = zeros(size(machs));
cd_f = zeros(size(machs));
cd_p = zeros(size(machs));

for k = 1:numel(machs)
    M = machs(k);
    cpPath = fullfile(dataDir, makeFileName(M, "Cp"));
    cfPath = fullfile(dataDir, makeFileName(M, "Cf"));
    [xCp, zCp, Cp] = readCoeffFile(cpPath);
    [xCf, zCf, Cf] = readCoeffFile(cfPath);

    % Remove duplicate points
    [xCp, zCp, Cp] = stripDuplicateEndpoint(xCp, zCp, Cp);
    [xCf, zCf, Cf] = stripDuplicateEndpoint(xCf, zCf, Cf);
    
    % Closed Airfoil
    [Cx_p, Cz_p, Cm_p] = pressureForcesAndMoment(xCp, zCp, Cp, x_ac, z_ac);

    % Friction
    [Cx_f, Cz_f] = frictionForces(xCf, zCf, Cf);

    % Total forces
    Cx = Cx_p + Cx_f;
    Cz = Cz_p + Cz_f;

    % Rotate to wind axes
    cl(k) = -Cx*sin(alpha) + Cz*cos(alpha);
    cd(k) =  Cx*cos(alpha) + Cz*sin(alpha);

    % Drag components
    cd_p(k) = Cx_p*cos(alpha) + Cz_p*sin(alpha);
    cd_f(k) = Cx_f*cos(alpha) + Cz_f*sin(alpha);

    % Moment coefficient about x_ac
    cmac(k) = Cm_p;
end

%% Plot cl, cd, c_mac vs Mach
figure;
plot(machs, cl, '-o', 'LineWidth', 1.5); grid on;
xlabel('Mach number'); ylabel('c_l');
title('c_l vs Mach');

figure;
plot(machs, cd, '-o', 'LineWidth', 1.5); grid on;
xlabel('Mach number'); ylabel('c_d');
title('c_d vs Mach');

figure;
plot(machs, cmac, '-o', 'LineWidth', 1.5); grid on;
xlabel('Mach number'); ylabel('c_{mac}');
title('c_{mac} vs Mach');

%% Print drag breakdown table
T = table(machs(:), cl(:), cd(:), cmac(:), cd_f(:), cd_p(:), ...
    'VariableNames', {'Mach','cl','cd','c_mac','cd_friction','cd_pressure'});
disp(T);

%% Cp distributions for required Mach numbers
mPlot = [0.1 0.6 0.7 0.85];

figure;
tiledlayout(2,2, 'Padding','compact', 'TileSpacing','compact');

for i = 1:numel(mPlot)
    M = mPlot(i);
    cpPath = fullfile(dataDir, makeFileName(M, "Cp"));
    [x, z, Cp] = readCoeffFile(cpPath);
    % Split at LE and reverse upper
    [xu, Cpu, xl, Cpl] = splitUpperLower_LEtoTE(x, Cp);

    nexttile;
    plot(xu, Cpu, 'LineWidth', 1.25); hold on;
    plot(xl, Cpl, 'LineWidth', 1.25);
    set(gca,'YDir','reverse'); grid on; % standard Cp plot convention
    xlabel('x/c'); ylabel('C_p');
    title(sprintf('C_p distribution, M = %.2g', M));
    legend('Upper','Lower','Location','best');
end

%% Helper Functions
function name = makeFileName(M, kind)
    if abs(M - 0.85) < 1e-12
        tag = "085";
    else
        tag = sprintf('%02d', round(10*M));
    end
    name = "4412_Ma" + tag + kind + ".txt";
end

function [x, z, coeff] = readCoeffFile(filename)
    fid = fopen(filename,'r');
    data = [];
    while ~feof(fid)
        line = strtrim(fgetl(fid));
        if isempty(line); continue; end
        vals = sscanf(line, '%f');
        if numel(vals) >= 4
            data = [data; vals(1:4).'];
        end
    end
    fclose(fid);
    x = data(:,1);
    z = data(:,3);
    coeff = data(:,4);
end

function [x, z, c] = stripDuplicateEndpoint(x, z, c)
    if numel(x) >= 2
        if abs(x(end)-x(1)) < 1e-12 && abs(z(end)-z(1)) < 1e-12
            x(end) = []; z(end) = []; c(end) = [];
        end
    end
end

function [Cx_p, Cz_p, Cm_p] = pressureForcesAndMoment(x, z, Cp, xref, zref)
    % Closed-loop line integral
    x2 = [x; x(1)];
    z2 = [z; z(1)];
    Cp2 = [Cp; Cp(1)];
    dx = diff(x2);
    dz = diff(z2);
    CpMid = 0.5*(Cp2(1:end-1) + Cp2(2:end));

    % Pressure force components
    dCx = -CpMid .* dz;
    dCz =  CpMid .* dx;
    Cx_p = sum(dCx);
    Cz_p = sum(dCz);

    % Pitching moment about x/z ref
    xMid = 0.5*(x2(1:end-1) + x2(2:end)) - xref;
    zMid = 0.5*(z2(1:end-1) + z2(2:end)) - zref;
    Cm_p = -sum(xMid .* dCz - zMid .* dCx);
end

function [Cx_f, Cz_f] = frictionForces(x, z, Cf)
    x2  = [x; x(1)];
    z2  = [z; z(1)];
    Cf2 = [Cf; Cf(1)];
    dx = diff(x2);
    dz = diff(z2);
    ds = hypot(dx, dz);

    % Unit tangent along the dataset direction
    tx = zeros(size(ds));
    tz = zeros(size(ds));
    good = ds > 0;
    tx(good) = dx(good)./ds(good);
    tz(good) = dz(good)./ds(good);
    CfMid = 0.5*(Cf2(1:end-1) + Cf2(2:end));

    % Shear Force Direction
    dCx = -CfMid .* tx .* ds;
    dCz = -CfMid .* tz .* ds;
    Cx_f = sum(dCx);
    Cz_f = sum(dCz);
end

function [xu, Cpu, xl, Cpl] = splitUpperLower_LEtoTE(x, Cp)
    [~, iLE] = min(x);
    xu  = flipud(x(1:iLE));
    Cpu = flipud(Cp(1:iLE));
    xl  = x(iLE:end);
    Cpl = Cp(iLE:end);
end