%% AEE 362 Problem 1

clc; clear; close all;

gamma = 1.4;
R     = 287;

rCrit = (2/(gamma+1))^(gamma/(gamma-1));

r = logspace(-3, 0, 2500);   % 1e-3 to 1

% p0 constant
p0_b = 800e3;
Yb   = mdot_sqrtT0_over_Ae(p0_b, r, gamma, R);

figure(1);
grid on; 
hold on;
semilogx(r, Yb, 'LineWidth', 1.8)
xline(rCrit,'--','Choke value','LabelVerticalAlignment','bottom');
xlabel('p_b/p_0')
ylabel('$\dot{m}\sqrt{T_0}/A_e$','Interpreter','latex')
title('p_0=800 kPa')

% pb constant
pb_c = 100e3;
p0_c = pb_c ./ r;
Yc   = mdot_sqrtT0_over_Ae(p0_c, r, gamma, R);

figure(2); grid on; hold on
semilogx(r, Yc, 'LineWidth', 1.8)
xline(rCrit,'--','Choke value','LabelVerticalAlignment','bottom');
xlabel('p_b/p_0')
ylabel('$\dot{m}\sqrt{T_0}/A_e$','Interpreter','latex')
title('p_b=100 kPa')

%% functions
function M = exitMach_from_pb_p0(r, gamma)
    rCrit = (2/(gamma+1))^(gamma/(gamma-1));
    M = zeros(size(r));

    sub = (r > rCrit);
    M(sub) = sqrt( (2/(gamma-1))*( r(sub).^(-(gamma-1)/gamma) - 1 ) );
    M(~sub) = 1; 
end

function Y = mdot_sqrtT0_over_Ae(p0, r, gamma, R)
    Me = exitMach_from_pb_p0(r, gamma);
    expo  = - (gamma+1)/(2*(gamma-1));
    flowFn = Me .* (1 + (gamma-1)/2 .* Me.^2).^expo;
    Y = p0 .* sqrt(gamma/R) .* flowFn;
end