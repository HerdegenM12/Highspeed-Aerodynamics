%% AEE 362 - HW 3 Problem 1

clc; clear; close all;

%% Parameters
% Helium
g4 = 1.66;
R4 = 2077; % J/kg K
p4 = 400e3; % Pa
T4 = 400; % K

% Argon
g1 = 1.667;
R1 = 208; % J/kg K
p1 = 20e3; % Pa
T1_ar = 15 + 273.15; % K

t = 1e-3; % ms
a1 = sqrt(g1*R1*T1_ar);
a4 = sqrt(g4*R4*T4);
rho1 = p1/(R1*T1_ar); % Ar in region 1

%% Build first-principles matching equation u_shock(p)=u_exp(p)
rho2_from_p = @(p) rho1 .* ( ((g1+1).*(p./p1) + (g1-1)) ./ ((g1-1).*(p./p1) + (g1+1)) );

u_shock = @(p) sqrt( max(0,(p-p1)) .* (1/rho1 - 1./rho2_from_p(p)) );

% Isentropic rarefaction into Helium
u_exp = @(p) (2*a4/(g4-1)) .* ( 1 - (p./p4).^((g4-1)/(2*g4)) );

fun = @(p) u_shock(p) - u_exp(p);

%% Solve for p*
pL = p1*(1 + 1e-9);
pU = p4*(1 - 1e-9);
 
fL = fun(pL); fU = fun(pU);
if sign(fL) == sign(fU)
    pstar = fminbnd(@(p) abs(fun(p)), pL, pU);
else
    pstar = fzero(fun, [pL, pU]);
end

ustar = u_shock(pstar); % m/s

fprintf(' STAR STATE\n');
fprintf('p* = %.3f kPa\n', pstar/1000);
fprintf('u* = %.3f m/s\n\n', ustar);

%% Region properties for plots
% Region 3
T3 = T4 * (pstar/p4)^((g4-1)/g4)
a3 = sqrt(g4*R4*T3);

% Region 2
rho2 = rho2_from_p(pstar);
T2_shocked = pstar/(rho2*R1) % ideal gas

%% Wave speeds and positions at time t
r = pstar/p1;
Ms = sqrt( 1 + ((g1+1)/(2*g1))*(r-1) ); % shock Mach into region 1
Vs = Ms*a1; % shock speed (m/s)

% Contact surface speed
Vc = ustar;

V_head = -a4;  
V_tail = ustar - a3;

% Locations at time t
x_head = V_head*t;
x_tail = V_tail*t;
x_contact = Vc*t;
x_shock = Vs*t;

fprintf(' WAVE LOCATIONS at t = %.3f ms\n', t*1e3);
fprintf('x_head    = %+8.5f m\n', x_head);
fprintf('x_tail    = %+8.5f m\n', x_tail);
fprintf('x_contact = %+8.5f m\n', x_contact);
fprintf('x_shock   = %+8.5f m\n\n', x_shock);

%% Build x-grid and piecewise field
xmin = 1.15*x_head;
xmax = 1.15*x_shock;
x = linspace(xmin, xmax, 4000);
xi = x./t;

u = zeros(size(x));
p = zeros(size(x));
T = zeros(size(x));

% Region 4
idx4 = (x < x_head);
u(idx4) = 0;
p(idx4) = p4;
T(idx4) = T4;

% Expansion fan
idxfan = (x >= x_head) & (x <= x_tail);

gamma = g4; aL = a4;
u(idxfan) = (2/(gamma+1))*(aL + xi(idxfan));
a_fan     = (2/(gamma+1))*(aL - (gamma-1)/2 * xi(idxfan));

p(idxfan) = p4 * (a_fan/a4).^(2*gamma/(gamma-1));
T(idxfan) = (a_fan.^2)./(g4*R4);

% Region 3 
idx3 = (x > x_tail) & (x < x_contact);
u(idx3) = ustar;
p(idx3) = pstar;
T(idx3) = T3;

% Region 2 
idx2 = (x > x_contact) & (x < x_shock);
u(idx2) = ustar;
p(idx2) = pstar;
T(idx2) = T2_shocked;

% Region 1 
idx1 = (x > x_shock);
u(idx1) = 0;
p(idx1) = p1;
T(idx1) = T1_ar;

%%  6) Plots
figure; plot(x, u, 'LineWidth', 1.5); grid on;
xlabel('x (m)'); ylabel('u (m/s)'); title('Velocity at t = 1 ms');
xline(x_head,'--'); xline(x_tail,'--'); xline(x_contact,'--'); xline(x_shock,'--');

figure; plot(x, p/1000, 'LineWidth', 1.5); grid on;
xlabel('x (m)'); ylabel('p (kPa)'); title('Pressure at t = 1 ms');
xline(x_head,'--'); xline(x_tail,'--'); xline(x_contact,'--'); xline(x_shock,'--');

figure; plot(x, T, 'LineWidth', 1.5); grid on
xlabel('x (m)'); ylabel('T (K)'); title('Temperature at t = 1 ms');
xline(x_head,'--'); xline(x_tail,'--'); xline(x_contact,'--'); xline(x_shock,'--');