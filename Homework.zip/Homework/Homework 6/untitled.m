%% AEE 362 Homework 6 - Problem 1

clc; clear; close all;

%% Givens
gamma = 1.4;
M_list = [1.5, 2.5, 4.0];

%% Preallocate storage
nPts = 400;
alpha_plot_all = cell(length(M_list),1);
CL_all = cell(length(M_list),1);
CD_all = cell(length(M_list),1);
LD_all = cell(length(M_list),1);
alpha_max_all = zeros(length(M_list),1);

%% Main loop over Mach number
for i = 1:length(M_list)
    M = M_list(i);

    % Largest turning angle for which attached oblique shock exists
    alpha_max_rad = thetaMax(M, gamma);
    alpha_max_deg = rad2deg(alpha_max_rad);
    alpha_max_all(i) = alpha_max_deg;

    % For plotting, stay just slightly below the exact limit
    alpha_plot_deg = linspace(0, 0.98*alpha_max_deg, nPts);
    CL = zeros(size(alpha_plot_deg));
    CD = zeros(size(alpha_plot_deg));
    LD = zeros(size(alpha_plot_deg));
    for k = 1:length(alpha_plot_deg)
        alpha_deg = alpha_plot_deg(k);
        [CL(k), CD(k)] = flatPlateCoeffs(M, alpha_deg, gamma);
        if abs(CD(k)) > 1e-12
            LD(k) = CL(k)/CD(k);
        else
            LD(k) = NaN;
        end
    end
    alpha_plot_all{i} = alpha_plot_deg;
    CL_all{i} = CL;
    CD_all{i} = CD;
    LD_all{i} = LD;
end

%% Display max valid angle of attack
fprintf('Maximum valid angle of attack values:\n');
for i = 1:length(M_list)
    fprintf('M = %.1f, alpha_max = %.6f deg\n', M_list(i), alpha_max_all(i));
end

%% Plot CL vs alpha
figure('Color','w');
hold on; grid on;
for i = 1:length(M_list)
    plot(alpha_plot_all{i}, CL_all{i}, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('M = %.1f', M_list(i)));
end
xlabel('\alpha (deg)');
ylabel('C_L');
title(' C_L vs \alpha');
legend('Location','northwest');

%% Plot CD vs alpha
figure('Color','w');
hold on; grid on;
for i = 1:length(M_list)
    plot(alpha_plot_all{i}, CD_all{i}, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('M = %.1f', M_list(i)));
end
xlabel('\alpha (deg)');
ylabel('C_D');
title(' C_D vs \alpha');
legend('Location','northwest');

%% Plot CD vs CL
figure('Color','w');
hold on; grid on;
for i = 1:length(M_list)
    plot(CL_all{i}, CD_all{i}, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('M = %.1f', M_list(i)));
end
xlabel('C_L');
ylabel('C_D');
title(' C_D vs C_L');
legend('Location','northwest');

%% Plot L/D vs CL
figure('Color','w');
hold on; grid on;
for i = 1:length(M_list)
    plot(CL_all{i}, LD_all{i}, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('M = %.1f', M_list(i)));
end
xlabel('C_L');
ylabel('L/D');
title(' L/D vs C_L');
legend('Location','northeast');

%% Local Functions
function [CL, CD] = flatPlateCoeffs(Minf, alpha_deg, gamma)
    alpha = deg2rad(alpha_deg);

    % Compression through attached oblique shock
    beta = solveBetaWeak(Minf, alpha, gamma);
    Mn1 = Minf * sin(beta);
    pL_pInf = 1 + (2*gamma/(gamma+1))*(Mn1^2 - 1);

    % Prandtl-Meyer expansion
    nu_inf = prandtlMeyer(Minf, gamma);
    nu_upper = nu_inf + alpha;
    M_upper = invPrandtlMeyer(nu_upper, gamma);
    pU_pInf = ((1 + (gamma-1)/2*Minf^2) / ...
              (1 + (gamma-1)/2*M_upper^2))^(gamma/(gamma-1));

    % Pressure coefficients
    Cp_lower = (2/(gamma*Minf^2))*(pL_pInf - 1);
    Cp_upper = (2/(gamma*Minf^2))*(pU_pInf - 1);

    % For a flat plate, force is normal to the plate
    CN = Cp_lower - Cp_upper;
    CA = 0;
    CL = CN*cos(alpha) - CA*sin(alpha);
    CD = CN*sin(alpha) + CA*cos(alpha);
end

function beta = solveBetaWeak(M, theta, gamma)
    mu = asin(1/M);

    % Zero turning angle
    if abs(theta) < 1e-12
        beta = mu;
        return;
    end

    % Maximum attached turning angle
    [theta_max_val, beta_peak] = thetaMaxWithBeta(M, gamma);

    % Prevent numerical trouble at the exact limit
    if theta >= theta_max_val
        theta = 0.999999 * theta_max_val;
    end

    % Weak branch exists only between mu and beta_peak
    beta_left  = mu + 1e-8;
    beta_right = beta_peak - 1e-8;
    f = @(beta) thetaFromBeta(M, beta, gamma) - theta;
    % Scan for sign change on weak branch only
    Nscan = 10000;
    beta_vals = linspace(beta_left, beta_right, Nscan);
    f_vals = arrayfun(f, beta_vals);
    idx = find(f_vals(1:end-1).*f_vals(2:end) <= 0, 1, 'first');

    if ~isempty(idx)
        beta = fzero(f, [beta_vals(idx), beta_vals(idx+1)]);
        return;
    end

    % Choose point with smallest residual
    [fmin_abs, j] = min(abs(f_vals));
    if fmin_abs < 1e-8
        beta = beta_vals(j);
        return;
    end
end

function theta_val = thetaFromBeta(M, beta, gamma)
    theta_val = atan( 2*cot(beta) .* ...
        ((M^2 .* sin(beta).^2 - 1) ./ ...
        (M^2 .* (gamma + cos(2*beta)) + 2)) );
end

function theta_max_val = thetaMax(M, gamma)
    [theta_max_val, ~] = thetaMaxWithBeta(M, gamma);
end

function nu = prandtlMeyer(M, gamma)
    nu = sqrt((gamma+1)/(gamma-1)) * atan( sqrt(((gamma-1)/(gamma+1))*(M^2-1)) ) ...
       - atan( sqrt(M^2-1) );
end

function M = invPrandtlMeyer(nu_target, gamma)
    f = @(M) prandtlMeyer(M, gamma) - nu_target;
    M = fzero(f, [1+1e-8, 50]);
end

function [theta_max_val, beta_peak] = thetaMaxWithBeta(M, gamma)
    beta_min = asin(1/M) + 1e-8;
    beta_max = pi/2 - 1e-8;

    fneg = @(beta) -thetaFromBeta(M, beta, gamma);
    beta_peak = fminbnd(fneg, beta_min, beta_max);

    theta_max_val = thetaFromBeta(M, beta_peak, gamma);
end