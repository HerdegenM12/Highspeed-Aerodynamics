%% AEE 362 Problem 2

clc; clear; close all;

gamma = 1.4;
AeAt  = 1.93;

%% Part A
Me_sub = machFromArea(AeAt, gamma, "sub");  % Me sub
pe_p0_sub = isen_p_over_p0(Me_sub, gamma);  % pe/p0
p0pb_choke = 1/pe_p0_sub;

Me_sup = machFromArea(AeAt, gamma, "sup"); % Me super
p0_p1  = 1/isen_p_over_p0(Me_sup, gamma); % p0/p1
p2_p1  = normalShock_p2_p1(Me_sup, gamma); % p2/p1
p0pb_shockExit = p0_p1 / p2_p1;
pe_p0_design = isen_p_over_p0(Me_sup, gamma);  % pe/p0 for supersonic exit
p0pb_design  = 1/pe_p0_design;                 % p0/pb

fprintf("Verification results (gamma = %.2f, Ae/At = %.2f)\n", gamma, AeAt);
fprintf("  Choking onset (Mt=1 first):  p0/pb = %.6f  \n", p0pb_choke);
fprintf("  Shock located at nozzle exit:  p0/pb = %.6f  \n",   p0pb_shockExit);
fprintf("  Fully isentropic supersonic exit p0/pb = %.6f  \n\n",    p0pb_design);

%% Part B/C


N = 500;
A1At = linspace(1.0001, AeAt-1e-4, N);

M1 = zeros(1,N);
M2 = zeros(1,N);
Me = zeros(1,N);
p0pb = zeros(1,N);

for i = 1:N
    Ar1 = A1At(i);
    M1(i) = machFromArea(Ar1, gamma, "sup");
    % Normal shock relations
    M2(i) = normalShock_M2(M1(i), gamma);
    A1_Astar2 = areaMach(M2(i), gamma);
    Ae_Astar2 = (AeAt/Ar1) * A1_Astar2;
    Me(i) = machFromArea(Ae_Astar2, gamma, "sub");
    p1_p0 = isen_p_over_p0(M1(i), gamma);
    p2_p1 = normalShock_p2_p1(M1(i), gamma);
    p02_p2 = 1/isen_p_over_p0(M2(i), gamma);
    p02_p0 = p02_p2 * p2_p1 * p1_p0;
    pe_p02 = isen_p_over_p0(Me(i), gamma);
    pb_p0 = pe_p02 * p02_p0;

    p0pb(i) = 1/pb_p0;
end

% Plot filtering
[p0pb_s, idx] = sort(p0pb);
M1_s   = M1(idx);
M2_s   = M2(idx);
Me_s   = Me(idx);
A1At_s = A1At(idx);

% Build requested pressure-ratio axis
pr = linspace(p0pb_choke, p0pb_shockExit, 250);

% Interpolate to get curves vs p0/pb
M1_plot   = interp1(p0pb_s, M1_s,   pr, "pchip");
M2_plot   = interp1(p0pb_s, M2_s,   pr, "pchip");
Me_plot   = interp1(p0pb_s, Me_s,   pr, "pchip");
A1At_plot = interp1(p0pb_s, A1At_s, pr, "pchip");

%% Plot M1, M2, and exit Mach vs p0/pb
figure(1); grid on; hold on
plot(pr, M1_plot, "LineWidth", 1.8)
plot(pr, M2_plot, "LineWidth", 1.8)
plot(pr, Me_plot, "LineWidth", 1.8)
xlabel("p0/pb", "Interpreter","none")
ylabel("Mach number", "Interpreter","none")
title("Normal shock inside a CD nozzle", "Interpreter","none")
legend("M1", "M2", "Me", "Location","best")

% Mark the endpoints
xline(p0pb_choke, "--", "choking begins", "LabelVerticalAlignment","bottom");
xline(p0pb_shockExit, "--", "shock at exit", "LabelVerticalAlignment","bottom");

%% Plot A1/At vs p0/pb
figure(2); grid on; hold on
plot(pr, A1At_plot, "LineWidth", 1.8)
xlabel("p0/pb", "Interpreter","none")
ylabel("A1/At  (shock location)", "Interpreter","none")
title("Shock location vs pressure ratio", "Interpreter","none")
xline(p0pb_choke, "--", "choking begins", "LabelVerticalAlignment","bottom");
xline(p0pb_shockExit, "--", "shock at exit", "LabelVerticalAlignment","bottom");

%% functions
function Ar = areaMach(M, gamma)
    g = gamma;
    Ar = (1./M) .* ( (2/(g+1) .* (1 + (g-1)/2 .* M.^2)) .^ ((g+1)/(2*(g-1))) );
end

function M = machFromArea(Ar_target, gamma, branch)
    f = @(M) areaMach(M, gamma) - Ar_target;

    if branch == "sub"
        M_lo = 1e-6;
        M_hi = 1 - 1e-6;
        M = fzero(f, [M_lo, M_hi]);
    else
        M_lo = 1 + 1e-6;
        M_hi = 50;  
        M = fzero(f, [M_lo, M_hi]);
    end
end

function p_p0 = isen_p_over_p0(M, gamma)
    g = gamma;
    p_p0 = (1 + (g-1)/2 .* M.^2) .^ (-g/(g-1));
end

function M2 = normalShock_M2(M1, gamma)
    g = gamma;
    M2 = sqrt( (1 + (g-1)/2 .* M1.^2) ./ (g .* M1.^2 - (g-1)/2) );
end

function p2_p1 = normalShock_p2_p1(M1, gamma)
    g = gamma;
    p2_p1 = 1 + (2*g/(g+1)) .* (M1.^2 - 1);
end