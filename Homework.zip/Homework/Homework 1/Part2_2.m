%% AEE 362 - HW 1 Part 2 - 2

clear; clc; close all;

% Parameters
gamma = 1.4;
M1 = linspace(0.4, 4.0, 600);
[pr, rhor, Tr, Vr, ds_cp] = normalShockRatios(M1, gamma);

% Plot
figure;
plot(M1, ds_cp, 'LineWidth', 2);
grid on;
xlabel('Mach number');
ylabel('\Delta s / c_p');
title('Entropy Change vs Mach Number');

%% Function
function [pr, rhor, Tr, Vr, ds_cp] = normalShockRatios(M1, gamma)
%   M1 - upstream Mach number
%   gamma - ratio of specific heats
%   pr - p2/p1
%   rhor - rho2/rho1
%   Tr - T2/T1
%   Vr - V2/V1
%   ds_cp - (s2-s1)/cp 
    % Pressure ratio
    pr = 1 + (2*gamma/(gamma+1)) .* (M1.^2 - 1);

    % Density ratio
    rhor = ((gamma+1) .* M1.^2) ./ (2 + (gamma-1) .* M1.^2);

    % Temperature ratio
    Tr = pr ./ rhor;

    % Velocity ratio from continuity
    Vr = 1 ./ rhor;

    % Entropy change
    ds_cp = log(Tr) - ((gamma-1)/gamma) .* log(pr);
end
