%% AEE HW 2 - Question 3

clc; clear; close all;

%% Parameters
gamma = 1.4;
R = 287;
cp = 1004;

T1 = 288; % K
T2 = 400; % K
T_ratio_target = T2 / T1;

% Function for T2/T1 as a function of M1
T2_T1 = @(M1) ...
    ( 1 + 2*gamma/(gamma+1)*(M1.^2 - 1) ) ./ ...
    ( ((gamma+1)*M1.^2) ./ (2 + (gamma-1)*M1.^2) );

% Solve for upstream Mach
f = @(M1) T2_T1(M1) - T_ratio_target;
M1 = fzero(f, 1.5); 

% Shock speed
a1 = sqrt(gamma*R*T1);
Vs = M1 * a1;

% Downstream Mach in shock-fixed frame
M2 = sqrt( (1 + 0.5*(gamma-1)*M1^2) / ...
           (gamma*M1^2 - 0.5*(gamma-1)) );

a2 = sqrt(gamma*R*T2);
u2 = M2 * a2; 
V2 = Vs - u2; 
M2_lab = V2 / a2;

T0_2 = T2 + V2^2/(2*cp);

%% Print Results
fprintf('Shock Mach Ms = %.3f, Vs = %.1f m/s\n', M1, Vs);
fprintf('Region 2: V2 = %.1f m/s, M2_lab = %.3f\n', V2, M2_lab);
fprintf('Region 2 stagnation temperature T0_2 = %.1f K\n', T0_2);