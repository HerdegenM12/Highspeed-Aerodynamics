%% AEE HW 2 - Question 2

clc; clear; close all;

%% Parameters
p_inf = 101e3; % kPa
T_inf = 20 + 273.15; % deg C
Va = 30; % m/s
Vb = 300; % m/s
gamma = 1.4;
R = 287; % J/(kg*K)

%% Upstream density and speed of sound
rho_inf = p_inf/(R*T_inf); % kg/m^3
a_inf   = sqrt(gamma*R*T_inf); % m/s

fprintf('Upstream density rho_inf = %.4f kg/m^3\n', rho_inf);
fprintf('Speed of sound a_inf = %.2f m/s\n\n', a_inf);

%% Part (a)
Va = 30; % m/s
Ma = Va / a_inf; % Mach number
qa = 0.5 * rho_inf * Va^2; % dynamic pressure

p0a_iso  = p_inf * (1 + 0.5*(gamma-1)*Ma^2)^(gamma/(gamma-1)); % isentropic
Cp_a_iso = (p0a_iso - p_inf) / qa;

p0a_bern  = p_inf + qa; % incompressible Bernoulli
Cp_a_bern = (p0a_bern - p_inf) / qa;

fprintf('Part A\n');
fprintf('Ma_a  = %.3f\n', Ma);
fprintf('q_a   = %.1f Pa\n', qa);
fprintf('p0_a (isentropic)  = %.3f kPa\n', p0a_iso/1e3);
fprintf('p0_a (Bernoulli)  = %.3f kPa\n', p0a_bern/1e3);
fprintf('Cp_stag_a (iso)  = %.4f\n', Cp_a_iso);
fprintf('Cp_stag_a (Bern)  = %.4f\n', Cp_a_bern);
fprintf('Rel diff (Bern vs iso) = %.2f %%\n\n', ...
        100*(p0a_iso - p0a_bern)/p0a_iso);

%% Part (b)
Mb = Vb / a_inf;  % Mach number
qb = 0.5 * rho_inf * Vb^2;  % dynamic pressure

p0b_iso  = p_inf * (1 + 0.5*(gamma-1)*Mb^2)^(gamma/(gamma-1));  % isentropic
Cp_b_iso = (p0b_iso - p_inf) / qb;

p0b_bern  = p_inf + qb;  % incompressible Bernoulli
Cp_b_bern = (p0b_bern - p_inf) / qb;

fprintf('Part B \n');
fprintf('Ma_b   = %.3f\n', Mb);
fprintf('q_b   = %.1f Pa\n', qb);
fprintf('p0_b (isentropic)  = %.3f kPa\n', p0b_iso/1e3);
fprintf('p0_b (Bernoulli)  = %.3f kPa\n', p0b_bern/1e3);
fprintf('Cp_stag_b (iso) = %.4f\n', Cp_b_iso);
fprintf('Cp_stag_b (Bern) = %.4f\n', Cp_b_bern);
fprintf('Rel diff (Bern vs iso) = %.2f %%\n', ...
        100*(p0b_iso - p0b_bern)/p0b_iso);