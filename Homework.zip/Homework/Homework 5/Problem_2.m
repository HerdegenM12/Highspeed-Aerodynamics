%% AEE 362 HW 5 - Problem 2

clc; clear; close all;

%% Givens
gamma = 1.4;
M_inf = 3.429;
Me = 0.4;
theta_deg = 15;
theta = deg2rad(theta_deg);

%% Normal shock at inlet
M2_a = normalShockM2(M_inf, gamma);
p2_p1_a = normalShockP2P1(M_inf, gamma);
p0e_p0inf_a = shockP0Ratio(M_inf, M2_a, p2_p1_a, gamma);
pe_p2_a = isenP0overP(M2_a, gamma) / isenP0overP(Me, gamma);
pe_pinf_a = p2_p1_a * pe_p2_a;

fprintf('PART (a)\n');
fprintf('M2 after inlet normal shock = %.6f\n', M2_a);
fprintf('pe/pinf = %.6f\n', pe_pinf_a);
fprintf('p0e/p0inf = %.6f\n\n', p0e_p0inf_a);

%% Oblique shock + normal shock
beta = solveBetaWeak(M_inf, theta, gamma);
Mn1 = M_inf * sin(beta);
Mn2 = normalShockM2(Mn1, gamma);
M2_b = Mn2 / sin(beta - theta);   % Mach after oblique shock

% terminal normal shock at the shown location
M3_b = normalShockM2(M2_b, gamma);
Ae_At = areaMach(Me, gamma) / areaMach(M3_b, gamma);

fprintf('PART (b)\n');
fprintf('beta (deg) = %.6f\n', rad2deg(beta));
fprintf('Mach after oblique shock M2 = %.6f\n', M2_b);
fprintf('Mach after normal shock M3 = %.6f\n', M3_b);
fprintf('Ae/At = %.6f\n\n', Ae_At);

%% Pressure ratios for oblique + normal shock inlet
% oblique shock pressure ratios
p2_p1_b = normalShockP2P1(Mn1, gamma);
p02_p01_b = shockP0Ratio(M_inf, M2_b, p2_p1_b, gamma);

% normal shock pressure ratios
p3_p2_b = normalShockP2P1(M2_b, gamma);
p03_p02_b = shockP0Ratio(M2_b, M3_b, p3_p2_b, gamma);

% downstream diffuser is isentropic
pe_p3_b = isenP0overP(M3_b, gamma) / isenP0overP(Me, gamma);
pe_pinf_b = p2_p1_b * p3_p2_b * pe_p3_b;
p0e_p0inf_b = p02_p01_b * p03_p02_b;

fprintf('PART (c)\n');
fprintf('pe/pinf = %.6f\n', pe_pinf_b);
fprintf('p0e/p0inf = %.6f\n', p0e_p0inf_b);

%% Local functions
function val = isenP0overP(M, gamma)
    val = (1 + (gamma-1)/2 * M.^2).^(gamma/(gamma-1));
end

function AR = areaMach(M, gamma)
    AR = (1./M) .* ((2./(gamma+1) .* (1 + (gamma-1)/2 .* M.^2)) ...
        .^ ((gamma+1)/(2*(gamma-1))));
end

function M2 = normalShockM2(M1, gamma)
    M2 = sqrt((1 + (gamma-1)/2 * M1.^2) ./ ...
              (gamma * M1.^2 - (gamma-1)/2));
end

function p2_p1 = normalShockP2P1(M1, gamma)
    p2_p1 = 1 + 2*gamma/(gamma+1) * (M1.^2 - 1);
end

function p02_p01 = shockP0Ratio(M1, M2, p2_p1, gamma)
    p02_p01 = p2_p1 * ...
        (1 + (gamma-1)/2 * M2.^2).^(gamma/(gamma-1)) ./ ...
        (1 + (gamma-1)/2 * M1.^2).^(gamma/(gamma-1));
end

function beta = solveBetaWeak(M, theta, gamma)
    f = @(b) tan(theta) - 2*cot(b).*((M.^2 .* sin(b).^2 - 1) ./ ...
        (M.^2 .* (gamma + cos(2*b)) + 2));

    beta_min = asin(1/M) + 1e-6;
    beta = fzero(f, [beta_min, deg2rad(60)]); % weak-shock root
end